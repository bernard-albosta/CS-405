// Uncomment the next line to use precompiled headers
// #include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
// TEST_F(CollectionTest, AlwaysFail)
// {
//   FAIL();
// }

// Test that a single value can be added to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // Assert the collection is empty
  ASSERT_TRUE(collection->empty());
  // Assert there are 0 elements
  ASSERT_EQ(collection->size(), 0);


  add_entries(1);

  // Verify collection is not empty and contains 1 element
  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 1);
}


// Test that five values can be added to a collection.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  // Assert the collection is empty
  ASSERT_TRUE(collection->empty());
  // Assert there are 0 elements
  ASSERT_EQ(collection->size(), 0);

  add_entries(5);

  // Verify the collection contains 5 elements
  EXPECT_FALSE(collection->empty());
  EXPECT_EQ(collection->size(), 5);

}

// Test that max size is at least size for 0, 1, 5, and 10 elements
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
  // Check against an empty collection
  ASSERT_EQ(collection->size(), 0);
  EXPECT_GE(collection->max_size(), collection->size());

  // Check against collection with 1 element
  add_entries(1);
  ASSERT_EQ(collection->size(), 1);
  EXPECT_GE(collection->max_size(), collection->size());

  // Add 4 more elements to reach 5
  add_entries(4);
  ASSERT_EQ(collection->size(), 5);
  EXPECT_GE(collection->max_size(), collection->size());

  // Add 5 more elements to reach 10
  add_entries(5);
  ASSERT_EQ(collection->size(), 10);
  EXPECT_GE(collection->max_size(), collection->size());
}

// Test that capacity is at least size for 0, 1, 5, and 10 elements
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
  // Check against an empty collection
  ASSERT_EQ(collection->size(), 0);
  EXPECT_GE(collection->capacity(), collection->size());

  // Check a collection with 1 element
  add_entries(1);
  ASSERT_EQ(collection->size(), 1);
  EXPECT_GE(collection->capacity(), collection->size());

  // Add 4 more elements to reach 5
  add_entries(4);
  ASSERT_EQ(collection->size(), 5);
  EXPECT_GE(collection->capacity(), collection->size());

  // Add 5 more elements to reach 10
  add_entries(5);
  ASSERT_EQ(collection->size(), 10);
  EXPECT_GE(collection->capacity(), collection->size());
}

// Test that resizing increases the collection size
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
  // Start with 5 elements
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Increase the collection to 10 elements
  collection->resize(10);

  // Verify the new size
  EXPECT_EQ(collection->size(), 10);
}

// Test that resizing decreases the collection size
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
  // Start with 10 elements
  add_entries(10);
  ASSERT_EQ(collection->size(), 10);

  // Decrease the collection to 5 elements
  collection->resize(5);

  // Verify the new size
  EXPECT_EQ(collection->size(), 5);
}

// Test that resizing to zero empties the collection
TEST_F(CollectionTest, ResizeToZeroEmptiesCollection)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Resize the collection to 0 elements
  collection->resize(0);

  // Verify the collection is empty and contains 0 elements
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Test that clear removes all elements from the collection
TEST_F(CollectionTest, ClearRemovesAllElements)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Clear the collection
  collection->clear();

  // Verify the collection is empty and contains 0 elements
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}


// Test that erase(begin, end) removes all elements from the collection.
TEST_F(CollectionTest, EraseRangeRemovesAllElements)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Erase the full range of elements
  collection->erase(collection->begin(), collection->end());

  // Verify the collection is empty and contains 0 elements
  EXPECT_TRUE(collection->empty());
  EXPECT_EQ(collection->size(), 0);
}

// Test that reserve increases capacity without changing collection size
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Choose a capacity greater than the current capacity
  auto originalCapacity = collection->capacity();
  auto requestedCapacity = originalCapacity + 10;

  // Reserve storage for the requested number of elements
  collection->reserve(requestedCapacity);

  // Verify capacity meets the request and size is unchanged
  EXPECT_GE(collection->capacity(), requestedCapacity);
  EXPECT_EQ(collection->size(), 5);
}

// Test that at() throws std::out_of_range for an out-of-bounds index
TEST_F(CollectionTest, AtThrowsForOutOfBoundsIndex)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Verify index 5 throws because valid indexes are 0 through 4
  EXPECT_THROW(collection->at(5), std::out_of_range);
}

// Test that inserting a value at the beginning increases size and stores the value
TEST_F(CollectionTest, InsertAddsValueAtBeginning)
{
  // Add 5 elements and assert the starting size
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);

  // Insert 42 at the beginning of the collection
  collection->insert(collection->begin(), 42);

  // Assert the new size and verify the first element is 42
  ASSERT_EQ(collection->size(), 6);
  EXPECT_EQ(collection->at(0), 42);
}

// Test that at() throws std::out_of_range when the collection is empty
TEST_F(CollectionTest, AtThrowsWhenCollectionIsEmpty)
{
  // Assert the collection is empty
  ASSERT_TRUE(collection->empty());

  // Verify accessing index 0 throws because no elements exist
  EXPECT_THROW(collection->at(0), std::out_of_range);
}