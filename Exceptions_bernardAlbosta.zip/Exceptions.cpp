// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>
#include <stdexcept>

// Custom application error
class ApplicationException final : public std::runtime_error
{
  public:
    explicit ApplicationException(const char* message) : std::runtime_error(message) {}
};

bool do_even_more_custom_application_logic()
{
  // Throw runtime error exception
  std::cout << "Running Even More Custom Application Logic." << std::endl;
  throw std::runtime_error("Custom Application Logic failed.");
}

void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;
  try
  {
    if (do_even_more_custom_application_logic())
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
  }
  catch (const std::exception& error)
  {
    // Catch exception by reference
    std::cout << "Caught standard exception: " << error.what() << std::endl;
  }
  // Continue after local handler and throw new exception
  std::cout << "Leaving Custom Application Logic." << std::endl;
  throw ApplicationException("Custom ApplicationException thrown");
}

float divide(float num, float den)
{
  // Throw invalid argument exception if denominator is 0
  if (den == 0.0f)
    throw std::invalid_argument("Denominator cannot be 0");
  return (num / den);
}

void do_division() noexcept
{
  float numerator = 10.0f;
  float denominator = 0;
  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::invalid_argument& error) // Handle divide's exception locally
  {
    std::cout << "Caught division exception: " << error.what() << std::endl;
  }
}

int main()
{
  try
  {
    std::cout << "Exceptions Tests!" << std::endl;
    do_division();
    do_custom_application_logic();
  }
  catch (const ApplicationException& error) // Catch custom exception
  {
    std::cout << "Caught custom exception: " << error.what() << std::endl;
  }
  catch (const std::exception& error) // Catch standard exception
  {
    std::cout << "Caught standard exception: " << error.what() << std::endl;
    return 1;
  }
  catch (...) // Catch unmatched exceptions
  {
    std::cout << "Caught unknown exception" << std::endl;
    return 1;
  }
  return 0;
}