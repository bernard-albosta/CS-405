// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  std::string user_input; // Store the input safely so its length can be checked after reading

  std::cout << "Enter a value: ";
  std::cin >> user_input;

  // The original buffer allowed 19 characters + null terminator, so 19 was chosen for account number length
  if (user_input.size() > 19)
  {
    std::cout << "Invalid input; no more than 19 characters are allowed" << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;

    // Report failure by returning 1
    return 1;
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
